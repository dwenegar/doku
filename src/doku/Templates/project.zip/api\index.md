This is the documentation for the Scripting APIs of this package.
